﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC4WithDropDownListAndPostBack.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

public ActionResult Index(int? maxCnt = 50)
{
    ViewBag.TopTags = new List<SelectListItem>
        {
            new SelectListItem
                {
                    Text = "Top 25 Tags", 
                    Value = "25",
                    Selected = checkForSelectedValue(maxCnt ?? 0,25 )
                },
            new SelectListItem {Text = "Top 50 Tags", Value = "50",Selected = checkForSelectedValue(maxCnt ?? 0,50 )},
            new SelectListItem {Text = "Top 75 Tags", Value = "75",Selected = checkForSelectedValue(maxCnt ?? 0,75 )},
            new SelectListItem {Text = "All Tags", Value = "9999",Selected = checkForSelectedValue(maxCnt ?? 0,9999 )}
        };

    ViewBag.MaxCnt = maxCnt ?? 888;
    return View();
}

private bool checkForSelectedValue(int cnt, int maxCnt)
{
    return cnt == maxCnt;
}

      
     
    }
}
