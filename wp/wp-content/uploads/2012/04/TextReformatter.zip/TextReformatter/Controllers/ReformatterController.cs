﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace MvcLiteApp.Controllers
{
    public class ReformatterController : Controller
    {
        /// <summary>
        /// for stringbuilder, want output like this:
        ///    var sb = new StringBuilder();
        ///    sb.AppendLine("122323");
        ///    sb.Append("dkfjdkfj");
        ///    string finalString = sb.ToString();
        /// 
        /// for javascriptarray, output:
        ///    var array = ["abcdj efgh","kdjfk kdjfk","kdafjkasfsaf askfdj"]
        /// 
        /// 
        /// </summary>
        /// <param name="inputText"></param>
        /// <param name="stringbuilder"></param>
        /// <param name="javascriptarray"></param>
        /// <param name="noFormatting"> </param>
        /// <param name="outputwidth"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ConvertTextToFriendlyText(string inputText, bool? stringbuilder,bool? javascriptarray,bool? noFormatting, int? outputwidth)
        {
            bool success;
            string messageReturn;
            var outputDataList = new List<string>();

            try
            {
                if (!outputwidth.HasValue || outputwidth.Value == 0)
                {
                    outputwidth = 30;
                }

                var outputDataListPrelim = new List<string>();
                var words = inputText.Split(' ').ToList();
                var newLine = new StringBuilder();
                foreach (var word in words)
                {
                    if (newLine.Length + word.Length < outputwidth &&
                        word.Length < outputwidth)
                    {
                        newLine.Append(" ");
                        newLine.Append(word);
                    }
                    else
                    {
                        outputDataListPrelim.Add(newLine.ToString().Trim());
                        newLine = new StringBuilder();
                        newLine.Append(word);
                    }
                }
                if (newLine.Length > 0)
                {
                    outputDataListPrelim.Add(newLine.ToString().Trim());
                }

                if (stringbuilder.HasValue && stringbuilder.Value)
                {
                    outputDataList.Add("var sb = new StringBuilder();");
                    outputDataList.AddRange(
                        outputDataListPrelim.Select(rec => String.Format("sb.AppendLine(\"{0}\");", rec)));
                    outputDataList.Add("string finalString = sb.ToString();");
                }
                else if (javascriptarray.HasValue && javascriptarray.Value)
                {
                    outputDataList.Add("var javaScriptArray = {[");
                    for (int index = 0; index < outputDataListPrelim.Count; index++)
                    {
                        var rec = outputDataListPrelim[index];
                        string addComma = "";
                        if (index < outputDataListPrelim.Count -1)
                        {
                            addComma = ",";
                        }
                        outputDataList.Add(String.Format("\"{0}\"{1}", rec, addComma));
                    }
                    outputDataList.Add("]}");
                }
                else
                {
                    // no formatting if not recognized from UI
                    outputDataList.AddRange(outputDataListPrelim);
                }



                success = true;
                messageReturn = "";
            }
            catch (Exception e)
            {
                messageReturn = e.ToString();
                success = false;
            }


            return Json(new
            {
                Success = success,
                Data = outputDataList,
                message = messageReturn
            }, JsonRequestBehavior.DenyGet);
        }

    }
}
